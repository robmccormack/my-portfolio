##YouTube JavaScript APIs  with Bootstrap 3


#Let's take a break soon



Status:
- [x] beta
- [ ] alpha
- [ ] stable

##GitHub Pages:
http://robmccormack.github.io/tb-youtube-api/


---

###Demo
http://bootsnipp.com/user/snippets/93RW


###Screen Shots
![](https://raw.github.com/robmccormack/tb-youtube-api/master/img_docs/screenshot1.png)

---

![](https://raw.github.com/robmccormack/tb-youtube-api/master/img_docs/screen-responsive.png)




By: Mr. M.

